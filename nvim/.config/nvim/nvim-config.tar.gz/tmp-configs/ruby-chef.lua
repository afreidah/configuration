-- Basic settings (many are defaults in Neovim, but shown here for completeness)
vim.cmd [[
  syntax on
  filetype plugin indent on
]]

-- Syntastic statusline integration
vim.opt.statusline:append('%#warningmsg#')
vim.opt.statusline:append('%{SyntasticStatuslineFlag()}')
vim.opt.statusline:append('%*')

-- Syntastic behavior
vim.g.syntastic_always_populate_loc_list = 1
vim.g.syntastic_auto_loc_list        = 1
vim.g.syntastic_check_on_open        = 1
vim.g.syntastic_check_on_wq          = 0
vim.g.syntastic_terraform_tffilter_plan = 1

-- Terraform completion settings
vim.g.terraform_completion_keys              = 1
vim.g.terraform_registry_module_completion   = 0

-- Remove 'preview' from completeopt
vim.opt.completeopt:remove('preview')

-- Close the preview window when the popup menu disappears
local autocmd = vim.api.nvim_create_autocmd
local group = vim.api.nvim_create_augroup
local filter_group = group('ClosePreviewOnPum', { clear = true })

autocmd({'CursorMovedI', 'InsertLeave'}, {
  group = filter_group,
  pattern = '*',
  callback = function()
    if vim.fn.pumvisible() == 0 then
      vim.cmd('pclose')
    end
  end,
})
