-- IndentLine configuration in Lua for Neovim
-- vim.g.indentLine_char = '|'
vim.g.indentLine_char = '·'
vim.g.indentLine_first_char = '-'
vim.g.indentLine_showFirstIndentLevel = 1
vim.g.indentLine_setColors = 0
